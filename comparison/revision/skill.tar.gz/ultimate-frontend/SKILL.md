---
name: ultimate-frontend
description: Design, build, refine or review websites and product interfaces. Use for new visual work, redesigns, interaction design and visual QA. Direct the composition from the subject, build its defining experience, remove AI design tells and test the rendered result.
---

# Ultimate Frontend

Give the visitor something worth **looking at, understanding or using**, not an introduction to an interface. For an open creative brief, spend the best part of the build on the thing the site exists to show. The visitor should recognize the subject and remember a particular experience of it, even with the logo covered. For a tool, the equivalent is being able to complete the job right on the working surface.

## First production decision

On an open creative build, your **first runnable screen is a study of the subject**, not the finished homepage. Literally write and render that study in the entry page before building the site around it. Spend the first implementation pass on one relationship that belongs to the subject: how it is made, changes, is compared, is navigated or is used. Show both sides of that relationship in real material. Let the visitor explore it when doing so explains something; a generic slideshow or zoom control alone does not count. A well-edited static sequence is equally valid.

**Stop and preview here.** This first render contains the subject and its local affordance or caption, *without* a site header, brand billboard, introductory hero, full section list or template gallery. Do not write the rest of the page in the same batch as this checkpoint. Without a browser, inspect the built study's geometry and source order at this boundary. If what you have made is just an illustration that could be dropped into any hero, the study is unfinished. Once it stands on its own, keep this composition as the opening of the delivered site; bring identity and navigation to its edges. Do not shrink it into the image half of a later hero. This production order is for creative work from scratch, not approved comps, tools or surgical fixes.

## Choose the route

Inspect the brief, project conventions, available material and current screen. Preserve specified flows, branding and approved comps. A short prompt delegates design decisions; it does not require an interview. Ask only when an unknown changes the task or makes a real-world claim unsafe.

| Request | Work to do | Exit condition |
| --- | --- | --- |
| New site or substantial redesign | Direction → first frame → main action → redline, below | The idea survives the actual render, the next section and the phone. |
| Implement an approved comp | Skip direction auditions. Map its type, crop, working edges, active control and negative space at the comp's viewport. Place the actual material before the chrome. | Compare captures at the reference size, then adapt without losing its hierarchy. Don't introduce a new signature. |
| Fix or refine a surface | Capture the affected state; identify the obstacle. Use only the relevant interaction or redline pass. | Same task and width before/after, obstacle gone, unrelated identity intact. |
| Critique only | Inspect pixels and try the main task. Report location → visitor consequence → specific remedy, distinguishing observed failures from preference. | Evidence-backed findings; no implementation. |

## 1. Direct the work before choosing components

For new work read [Direction studies](references/direction-studies.md) and [Composition](references/composition.md). Use the user's own nouns. Decide whether this surface is for experiencing work, deciding, operating or reading. Find the material that answers the visitor's first real question. Build two competing thumbnails of the first screen **and its handoff**, with the same words and material: one obvious answer and one fundamentally different reading path. A change of font or palette does not count. Select the stronger one, not necessarily the stranger one.

Keep a short **composition lock** in working notes: `first thing seen / extent and working edge / what the visitor does to it / next beat / phone transformation`. For an expressive site also name the one thing you will **make**, not just style: an original body of work, a working product view, a sequence of scenes, an instrument, a photographic edit. “Oversize type, grain and micro-interactions” is not an artifact. If removing the ornament leaves the same sales page as the rejected thumbnail, change the structure now. Never print the lock, design rationale or invented proof on the website.

### Reject the interchangeable skeleton (open creative briefs)

For a new expressive site without an approved layout, **reject** the candidate if its wireframe reads `top nav → introduction beside/above an illustration → button to the real content → equal tiles`. This is a failed comp even when the illustration is excellent. Do not rebuild it with a better image or swap the two columns. It makes the visitor pass an advertisement to reach the thing they came for. The same goes for a screen-sized slogan with the work hidden below it. This is a composition gate, not a ban on columns or grids inside a useful surface.

Use the next beat for a new view, scale, relationship or stage of the task. A lead object repeated unchanged as item one immediately below is a failed handoff. Neither beat needs a kicker, figure number, badge, arrow or motto by default. Remove cues that merely announce taste.

**Cheap wireframe test:** in working notes, erase every adjective, color and illustration subject from your lock. Could it describe the rejected structure word for word? If yes, **discard the layout before markup**. Name the first meaningful action available without following an anchor to the actual experience. If a browser is available, apply the same test to the first preview. Correct a failed frame structurally; a note in the final report isn't a repair.

## 2. Construct the first frame and inspect it before extending the page

Start with the focal artifact and real content, not a header/hero/card component kit. Choose its medium, make enough of it to judge it, and arrange the first viewport **around** it. Use [Build the frame](references/build-the-frame.md) for production and fallback choices. Build the primary action and the start of the next beat. Take a desktop **and a phone** preview now if available. If an introduction displaces the work, or the control appears to operate a picture rather than the real thing, correct that geometry before building more sections. One corrective edit to the actual frame is worth a page of rationale.

Continue the same visual grammar, not the same box. Let the next visitor question determine the next structure. A mark or layout rule should do a second useful job elsewhere. Write in the visitor's language, with actual names and verbs; delete lines whose only job is to make the design sound intentional. For fictional work, original sample material is fine; testimonials, stock counts, credentials, addresses and live services are not yours to invent.

## 3. Make the main action work under the hand

Read [Interaction](references/interaction.md) when building a selectable object, disclosure, overlay, gesture or transition. Even a quiet site has a path: see something → act → see the result → return without losing one's place. Use native activation, immediate feedback, a clear current state, visible keyboard focus and a usable touch target. Never make hover the only explanation. When a gesture adds value, preserve direct tracking and interruption; provide the same outcome without dragging. Reduce travel for reduced motion without removing meaning. If a backend is unavailable, choose an honest local action that still helps instead of simulating success.

## 4. Redline before delivery

On new work read the [Unslop sign-to-repair catalog](references/signs.md) and apply its families to the actual screen, not as a style preset. For a localized refinement inspect only the affected families. Check the replacement cliché too: a monochrome editorial spread, numbered chapters and tiny uppercase captions everywhere can be as interchangeable as gradient bento cards. A deliberately expressive typeface, color or physical interaction may stay when it serves this work. Preserve accessibility and the user's design system over any stylistic default.

Use the [browser finish check](references/finish-check.md). Inspect the opening and next beat at two widths; exercise the main action, keyboard return and any applicable empty/error states. Repair missing subject matter or broken interaction before polishing. Recheck the changed state. If browser or asset tools are unavailable, still deliver the best viable surface and state exactly what could not be verified. Don't claim a visual pass from source alone.

Source credits: Anthropic, Emil Kowalski, Leonxlnx, Paul Bakaus, and [Damir Sokolovsky's Unslop](https://github.com/heydamir/unslop) ([CC BY 4.0](https://creativecommons.org/licenses/by/4.0/), adapted). Pinned sources and modification notes are in the distribution's `ATTRIBUTION.md`.
