# Build from the visitor's encounter

Use this route for a new creative site or a substantial open redesign. Do not use it to reinterpret an approved comp, a reading brief, or a product task. A short brief delegates composition, not permission to invent business facts.

## First build: one complete encounter

Read [Direction studies](direction-studies.md). Choose between two ideas rooted in different properties of the subject. Think about what someone can discover directly through scale, juxtaposition, manipulation, sound, timing or another intrinsic relationship. Use what you can actually make well. A category illustration and a generic enlarge button are not a concept. Motion is optional.

Make this encounter a working, self-contained region of the actual page. The first preview should already show the intended opening composition, including its title and any local controls. Put that title **inside the same composition** as the material. Do not reserve a separate promotional column for it. No stock split of multiline pitch plus CTA on one side and framed example on the other. Design for the phone at the same time. See [Build the frame](build-the-frame.md) for media and typography.

**Freeze the accepted region.** Extend the page outside it; do not take its artwork out and use it to illustrate a conventional hero later. If tooling rewrites whole files, preserve the region's markup and spatial relationship. Only alter it to solve a concrete rendering, access or usability problem. Keep a distinctive typographic or material detail that works; it doesn't need a caption explaining it.

## Second build: a visitor outcome, not section inventory

Choose the next thing a visitor can *actually do or learn* that isn't possible above. Compose its real material before furnishing it. Let the first encounter affect this one: what has the visitor chosen, examined or understood that now matters? It may be a consequence of a choice, an item brought closer, a useful comparison, an actual next action. It must work even with the header and hero cropped away. Continue only while there is a new job to serve. A single integrated surface can be a complete website. A real brief may instead warrant many pages. No generic About, process paragraph, recap or pitch footer by default.

In an open creative build, **reject the pattern, not just the number three**: equal self-contained tiles repeating a picture, label, teaser and arrow. This includes genuine work samples, not only generic features. Staggering the tiles or changing their count isn't a new reading path. Don't replace every deck with a numbered list driving a preview, either. Compose relationships between actual pieces, their size, order, affordance and whitespace. Consistent rows or grids are right when a specified task actually requires scanning comparable attributes.

## Typeset an approved vocabulary, not placeholder copy

Before writing public markup, make a private list of the exact visible strings needed for this encounter. Start with the title, object names, actions and values. Include any supplied prose, real distinguishing facts, units, necessary instructions and recovery. Write the HTML **from that list**. Do not fill a layout with draft copy and plan to trim it later. Keep notes off the site.

For an open showcase with no supplied text, the default page has **no promotional paragraph, eyebrow, specimen number, count subtitle, helper sentence under a self-explanatory control, or paragraph in the footer**. For each exception identify the choice that would be wrong without those exact words. No such choice: omit the node, not just its border. Don't narrate a visible color, count visible items or repeat the category above and below the title. Use an object's name once per immediate context. Express hierarchy through geometry instead of inventing text roles. Do not apply the showcase default to requested journalism or explanatory content. Keep accessible names, meaningful headings and visible input labels.

## Cut against the implementation

1. Read the **actual visible text in DOM order**, including after the opening. Diff it against the private list. Remove newly invented filler from the source before delivery; changing it to a shorter slogan is not a cut. Fix the surrounding space instead. No requirement to expose the list to the user.
2. Inspect the opening against its first preview, then the middle without it and the final action. If the subject has become a conventional hero illustration, restore the accepted region. If the rest could be lifted into a neighboring business by swapping image URLs, fix the relationship, not the border radius.
3. Apply the relevant [Unslop signs](signs.md), [Interaction](interaction.md), and [browser finish check](finish-check.md). Try the intended outcome with keyboard and touch, including exit or recovery; preserve a reduced-motion path. No browser? Inspect the source order and report the visual gap. Do not add polish to hide a failed cut.
