---
name: ultimate-frontend
description: Design, implement and critique websites and product interfaces. Use for art direction, content editing, responsive composition, interaction design and visual QA. Build work that belongs to the subject, from the opening through the last action.
---

# Ultimate Frontend

Choose the route first. The user's brief, approved design system, real content and accessibility requirements outrank stylistic defaults. A short brief delegates decisions; missing business facts do not grant permission to invent them.

| Route | Start | Stop when |
| --- | --- | --- |
| Open creative site or substantial redesign | Follow the production sequence below. | The opening **and the rest of the page** survive the sequence and copy cuts. |
| Working product or reading interface | Start with a hard real task, its data and its outcome. Use [Composition](references/composition.md) and [Interaction](references/interaction.md). | The user can complete and undo or recover from the task. Use conventional lists, grids and tables where they support comparison. No creative-site quota. |
| Approved comp | Map its working edges, type, crop, controls and source order. Preserve the comp; adapt deliberately at other widths. | The rendered states match the brief. Don't audition a new identity. |
| Local refinement / critique | Inspect only the affected route, state and viewport; use the relevant diagnostic family. | The obstacle is gone or, for critique only, documented with a concrete remedy. Don't rebuild the site. |

For right-to-left content read [RTL layout and typography](references/rtl.md) before arranging the page.

## 1. Choose what the visitor will experience

Read [Direction studies](references/direction-studies.md). Compare two ideas from **different properties of the subject**, not two skins on a category template. What can the visitor see or do here that a neighbor's site wouldn't offer? Choose the idea with the strongest answer and feasible material. Write down the focal artifact, its action or revealing static relationship, and its phone translation in working notes, not on the site. Don't turn quirky punctuation, a specific typeface or another site's signature into a house style.

Build the subject study **before the homepage**. Put the actual material and its local affordance into the entry page and preview it before writing the header, intro or section list. Use [Build the frame](references/build-the-frame.md) for medium and asset choices. A generic zoom, slider or decorative shader alone isn't an idea. An interaction should reveal a property of the subject; when static material does that better, leave it still. The study is the working page, not a disposable asset preview. Grow the page by extending it; do not replace it with a second homepage. Preserve its dominant scale, reading path and local affordance at both widths. If later markup would place a large introduction beside a thumbnail of the study, reject that markup. Do not add a detached hero CTA when the object already offers the same action.

## 2. Compose the *rest* before furnishing it

Treat the opening as one accepted scene, not a license to append a landing-page kit. **The next implementation pass is a bare sequence, not finished sections.** Start with actual works, tasks, events, facts or choices. For every proposed beat, name what the visitor can learn or do there that was unavailable one beat earlier. No new answer? Merge it or leave it out. A short, finished site is better than a tour of generic sections. Do not infer an About, process explainer, teaching program, contact pitch or recap footer from a site category. Keep any of these the user asked for, or one that delivers a distinct, supported visitor outcome. Otherwise end at the last useful object or action; the page doesn't owe the reader a conclusion.

Sketch that sequence all the way to its last useful action. At middle scroll, with the opening cropped away, the chosen concept must still determine how material is seen or used. Give the second scene a relationship to the first (whole/detail, consequence, contrasting material, continuation of a choice, or something else intrinsic). Work out where the eye enters and exits each scene and what remains when the layout gets narrow. It isn't enough to give adjacent sections different background colors.

**Creative collection rule, independent of the hero:** do not generate a row of three equal picture/title/description panels or three interchangeable feature blocks on an open creative site. This applies to work samples, services, techniques, process steps and the footer as well as features. Removing borders, varying tints, using two or four cards instead, or staggering the same repeated module is not a fix. Decide what the visitor should examine, in what order and at what scale. Build that relation: a detail can interrupt a larger composition; many names can address a single changing view; two unlike objects may need to confront one another directly. These are reasoning examples, not a menu to rotate. An explicit supplied grid or a true comparison task with shared attributes is a different route; preserve it. Do not ban all repetition or make every item a different puzzle.

## 3. Set type with the copy already cut

**Begin the bare sequence without intro paragraphs, eyebrows, card descriptions, section subtitles or closing mottos.** Add words only when a visitor would otherwise misunderstand an action, miss a distinction not visible in the material, or lose an authored passage the brief actually calls for. Read each proposed line next to the object, heading and control that already speak for it. Remove it temporarily. If the visitor can still identify the same thing, choose just as well and predict the same result, **delete the element; do not paraphrase it**. Leave the space empty or change the geometry. Do not refill it to balance a column.

- A title can stand alone. A section does not need to count its contents, classify itself or invite the reader to look. A working control needs an accurate label, not a second sentence narrating its visible effect.
- Put a fact next to the decision that needs it, once. Optional craft detail belongs in a requested reading view or detail state, not in the default frame of every object. If there is no detail worth opening, don't add a disclosure.
- Keep visible input labels, units, prerequisites, recovery instructions, meaningful headings, requested long-form writing and useful alt text. Accessible names are not visible filler. One expressive typographic choice can stay for its visual merit; it needn't earn an explanatory caption.

**Production checkpoint, before CSS polish:** render the whole default page using only proper names, the page title, necessary navigational headings, factual values and action labels. Preserve supplied editorial copy and functional instructions. Inspect this actual lean page, not a plan for one. A blank patch is a layout problem; don't commission a sentence to fill it. For an open creative brief with no supplied prose, this version is the default to ship. A new visible sentence needs a specific missing fact or an observed usability failure. Do not add a category eyebrow to a title already naming the category, a metadata synonym beside a heading, an ornamental ordinal beside a name, or a footer restating the opener. On reading or editorial briefs the authored text is the material, not decoration.

Only now finish type, spacing, edges, color and motion. Use [Interaction](references/interaction.md) for native activation, touch feedback, interruptible motion, focus and return. Keep a non-gesture path and reduced-motion behavior. Do not simulate a successful transaction or invent testimonials, addresses, credentials or live stock to fill a module.

## 4. Reject or ship the rendered page

Inspect the settled opening, **middle without the hero**, and ending. Try the main path on a phone and with a keyboard. Read the [Unslop catalog](references/signs.md) against the actual result, then use the [finish check](references/finish-check.md) for affected states. Specifically check the bare-sequence and deletion decisions against what actually shipped: a repeated promotional row anywhere or narration that just reads the screen aloud is an unfinished creative build. Remove or reconstruct the offending region before delivery. Do not swap in ornamental numbers, specimen labels or a new stock layout. Fix the offending beat, not the signature that worked. If no browser is available, inspect markup and source order and say what remains visually unverified.

Credits and modification notes for the combined methods: `ATTRIBUTION.md`. The Unslop catalog is by [Damir Sokolovsky](https://github.com/heydamir/unslop), [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
